# Kavach — Blockchain + Automation Layer

This is the real, working smart contract and off-chain automation behind the
Kavach prototype. It runs on a local Hardhat network (simulated EVM testnet,
not mainnet) — matching what the HTML prototype and pitch deck describe.

## What's in here

```
contracts/Kavach.sol      the smart contract — claim lifecycle, oracle-gated
                           attestation, threshold-based settle/block logic
scripts/compile.js        compiles Kavach.sol locally with solc.js
scripts/deploy.js         deploys + funds the payout pool
scripts/automate.js       plays the "AI oracle" role end to end — deploys,
                           files two seeded claims (one genuine, one
                           inconsistent), scores them, and submits
                           attestations on-chain. This is the automation demo.
test/Kavach.test.js       5 tests covering the settle path, the block path,
                           access control, and double-attestation protection
```

## How the pieces map to the pitch

- **On-chain**: attestation hash, damage score, rainfall deficit, claim state,
  payout amount. That's it — see `Kavach.sol`.
- **Off-chain**: the actual field photo, the raw weather time-series, farmer
  records. `scripts/automate.js` stands in for the real AI service — it
  "scores" seeded evidence and hashes the bundle before submitting.
- **The contract decides, not the AI**: `submitAttestation` is the only
  function that can move a claim out of PENDING, and its own threshold logic
  (not the oracle) decides SETTLED vs BLOCKED.

## Running it

```bash
npm install
npx hardhat test              # proves the contract works — 5 passing tests
npx hardhat run scripts/automate.js   # full demo: deploy + 2 claims, live
```

`automate.js` is the one to run live during judging — it prints every step
(claim filed → AI scoring → attestation hash → on-chain outcome) for both the
valid and the inconsistent claim, ending in one SETTLED and one BLOCKED claim
with real event logs.

## A note on the compiler

This sandbox's network egress only allows npm-related domains, and Hardhat's
default compiler manager needs `binaries.soliditylang.org`, which isn't
reachable here. `hardhat.config.js` disables Hardhat's built-in compile step
and `scripts/compile.js` compiles `Kavach.sol` locally instead, using the
pure-JS `solc` npm package (no binary download needed). On a normal machine
with full internet access, you can delete that override in
`hardhat.config.js` and use `npx hardhat compile` as usual — the contract
itself doesn't change either way.

## Demo thresholds (tune before any real deployment)

- `DAMAGE_THRESHOLD = 70` — damage score (0–100) needed to qualify at all
- `CONSISTENCY_THRESHOLD = 15` — minimum rainfall deficit % required to
  corroborate a high damage score
- `PAYOUT_PER_CLAIM = 0.01 ETH` — demo payout size, a stand-in value for the
  prototype, not a real premium calculation
