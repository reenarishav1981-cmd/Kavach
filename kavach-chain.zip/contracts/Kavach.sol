// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/// @title Kavach — Parametric Crop Insurance
/// @notice Farmers submit claims; an off-chain AI oracle attests damage score +
///         weather correlation; this contract enforces the payout/block decision.
///         AI never moves funds directly — it only writes an attestation, and the
///         contract's own threshold logic decides the outcome.
contract Kavach {
    enum ClaimState { NONE, PENDING, SETTLED, BLOCKED }

    struct Claim {
        address farmer;
        string plotId;
        string crop;
        uint256 damageScore;      // 0-100
        uint256 rainfallDeficit;  // percent, 0-100
        bytes32 attestationHash;  // keccak256 of off-chain evidence bundle
        ClaimState state;
        uint256 payoutAmount;
        uint256 timestamp;
    }

    address public owner;
    address public oracle; // address authorised to submit AI attestations

    uint256 public claimCounter;
    mapping(uint256 => Claim) public claims;

    // demo thresholds — tune these against real historical data before any real deployment
    uint256 public constant DAMAGE_THRESHOLD = 70;       // damage score needed to qualify at all
    uint256 public constant CONSISTENCY_THRESHOLD = 15;  // min rainfall deficit % to corroborate a high damage score
    uint256 public constant PAYOUT_PER_CLAIM = 0.01 ether; // demo payout size, simulated value

    event ClaimSubmitted(uint256 indexed claimId, address indexed farmer, string plotId, string crop);
    event AttestationRecorded(uint256 indexed claimId, bytes32 attestationHash, uint256 damageScore, uint256 rainfallDeficit);
    event ClaimSettled(uint256 indexed claimId, address indexed farmer, uint256 payoutAmount);
    event ClaimBlocked(uint256 indexed claimId, address indexed farmer, string reason);
    event OracleUpdated(address indexed oldOracle, address indexed newOracle);

    modifier onlyOracle() {
        require(msg.sender == oracle, "Kavach: caller is not the attestation oracle");
        _;
    }

    modifier onlyOwner() {
        require(msg.sender == owner, "Kavach: caller is not the owner");
        _;
    }

    constructor(address _oracle) payable {
        require(_oracle != address(0), "Kavach: oracle cannot be zero address");
        owner = msg.sender;
        oracle = _oracle;
    }

    /// @notice Insurer/owner tops up the payout pool. Kept separate from constructor
    ///         so the demo can show funding as its own on-chain step.
    function fundPool() external payable {}

    /// @notice Farmer files a claim. No evidence is stored on-chain here —
    ///         only plot/crop metadata needed to route the claim.
    function submitClaim(string calldata plotId, string calldata crop) external returns (uint256 claimId) {
        claimCounter += 1;
        claimId = claimCounter;

        claims[claimId] = Claim({
            farmer: msg.sender,
            plotId: plotId,
            crop: crop,
            damageScore: 0,
            rainfallDeficit: 0,
            attestationHash: bytes32(0),
            state: ClaimState.PENDING,
            payoutAmount: 0,
            timestamp: block.timestamp
        });

        emit ClaimSubmitted(claimId, msg.sender, plotId, crop);
    }

    /// @notice Called by the off-chain AI oracle service once it has scored the
    ///         field photo and cross-checked district rainfall data. This is the
    ///         only function that can move a claim out of PENDING.
    /// @param damageScore 0-100 vision-model damage score
    /// @param rainfallDeficit 0-100 percent rainfall deficit for the district/window
    /// @param attestationHash keccak256 hash of the full off-chain evidence bundle
    ///        (photo hash, weather series, model version) — lets anyone later
    ///        verify the off-chain record matches what was attested on-chain.
    function submitAttestation(
        uint256 claimId,
        uint256 damageScore,
        uint256 rainfallDeficit,
        bytes32 attestationHash
    ) external onlyOracle {
        Claim storage c = claims[claimId];
        require(c.state == ClaimState.PENDING, "Kavach: claim is not pending");
        require(damageScore <= 100 && rainfallDeficit <= 100, "Kavach: scores must be 0-100");

        c.damageScore = damageScore;
        c.rainfallDeficit = rainfallDeficit;
        c.attestationHash = attestationHash;

        emit AttestationRecorded(claimId, attestationHash, damageScore, rainfallDeficit);

        bool consistent = _isConsistent(damageScore, rainfallDeficit);

        if (damageScore >= DAMAGE_THRESHOLD && consistent) {
            c.state = ClaimState.SETTLED;
            c.payoutAmount = PAYOUT_PER_CLAIM;
            require(address(this).balance >= PAYOUT_PER_CLAIM, "Kavach: payout pool underfunded");

            (bool sent, ) = payable(c.farmer).call{value: PAYOUT_PER_CLAIM}("");
            require(sent, "Kavach: payout transfer failed");

            emit ClaimSettled(claimId, c.farmer, PAYOUT_PER_CLAIM);
        } else {
            c.state = ClaimState.BLOCKED;
            string memory reason = consistent ? "damage score below threshold" : "damage score inconsistent with district rainfall";
            emit ClaimBlocked(claimId, c.farmer, reason);
        }
    }

    /// @dev Demo consistency heuristic: a high damage claim must be corroborated
    ///      by a meaningful rainfall deficit in the same window. A low damage
    ///      score doesn't need weather corroboration since it isn't claiming a
    ///      weather-driven loss in the first place.
    function _isConsistent(uint256 damageScore, uint256 rainfallDeficit) internal pure returns (bool) {
        if (damageScore >= DAMAGE_THRESHOLD) {
            return rainfallDeficit >= CONSISTENCY_THRESHOLD;
        }
        return true;
    }

    function getClaim(uint256 claimId) external view returns (Claim memory) {
        return claims[claimId];
    }

    function setOracle(address newOracle) external onlyOwner {
        require(newOracle != address(0), "Kavach: oracle cannot be zero address");
        emit OracleUpdated(oracle, newOracle);
        oracle = newOracle;
    }

    function poolBalance() external view returns (uint256) {
        return address(this).balance;
    }

    receive() external payable {}
}
