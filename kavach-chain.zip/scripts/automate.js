/**
 * Kavach automation demo.
 *
 * Plays the role of the off-chain AI service: it "scores" two seeded claims
 * (one genuine, one inconsistent), hashes the evidence bundle, and submits
 * the attestation on-chain — where Kavach.sol's own threshold logic decides
 * whether to pay out or block. Run standalone:
 *
 *   npx hardhat run scripts/automate.js
 */
const hre = require("hardhat");
const { ethers } = hre;
const { compileKavach } = require("./compile");

// Seeded demo evidence — mirrors the prototype's valid/fraud scenarios.
// In a real deployment this would come from the vision model + a weather API.
const seededClaims = [
  {
    label: "Genuine damage claim",
    farmerIndex: 2,
    plotId: "MH-AGN-0472",
    crop: "Cotton",
    evidence: {
      photoHash: "sha256:field_damage_01.jpg",
      gps: "19.0948N,74.7480E",
      capturedAt: "2026-08-22T06:10:00Z",
      damageScore: 86,
      rainfallDeficitPct: 61,
      weatherSource: "IMD district feed (demo)",
    },
  },
  {
    label: "Inconsistent claim",
    farmerIndex: 3,
    plotId: "MH-AGN-0488",
    crop: "Cotton",
    evidence: {
      photoHash: "sha256:field_damage_02.jpg",
      gps: "19.1002N,74.7391E",
      capturedAt: "2026-08-18T05:40:00Z",
      damageScore: 81,
      rainfallDeficitPct: 4,
      weatherSource: "IMD district feed (demo)",
    },
  },
];

function attestationHashFor(evidence) {
  const bundle = JSON.stringify(evidence);
  return ethers.keccak256(ethers.toUtf8Bytes(bundle));
}

async function main() {
  const signers = await ethers.getSigners();
  const [deployer, oracle] = signers;

  console.log("=== Kavach automation run ===\n");
  console.log("Deploying Kavach.sol …");
  const { abi, bytecode } = compileKavach();
  const Kavach = new ethers.ContractFactory(abi, bytecode, deployer);
  const kavach = await Kavach.deploy(oracle.address);
  await kavach.waitForDeployment();
  const address = await kavach.getAddress();
  console.log("  contract:", address);
  console.log("  oracle:  ", oracle.address);

  const fundTx = await deployer.sendTransaction({ to: address, value: ethers.parseEther("1.0") });
  await fundTx.wait();
  console.log("  funded payout pool with 1.0 ETH (demo testnet value)\n");

  for (const item of seededClaims) {
    const farmer = signers[item.farmerIndex];
    console.log(`--- ${item.label} ---`);
    console.log("farmer:", farmer.address);

    // 1. Farmer files the claim (on-chain, minimal metadata only)
    const submitTx = await kavach.connect(farmer).submitClaim(item.plotId, item.crop);
    const submitReceipt = await submitTx.wait();
    const submittedEvent = submitReceipt.logs
      .map((l) => { try { return kavach.interface.parseLog(l); } catch { return null; } })
      .find((e) => e && e.name === "ClaimSubmitted");
    const claimId = submittedEvent.args.claimId;
    console.log(`claim filed -> id ${claimId}`);

    // 2. Off-chain "AI service" scores the evidence (this is the automation step)
    const { damageScore, rainfallDeficitPct } = item.evidence;
    const attestationHash = attestationHashFor(item.evidence);
    console.log(`AI scoring  -> damage ${damageScore}/100, rainfall deficit ${rainfallDeficitPct}%`);
    console.log(`attestation -> ${attestationHash}`);

    // 3. Oracle submits the attestation; the contract enforces the outcome
    const attestTx = await kavach
      .connect(oracle)
      .submitAttestation(claimId, damageScore, rainfallDeficitPct, attestationHash);
    const attestReceipt = await attestTx.wait();

    const outcomeEvent = attestReceipt.logs
      .map((l) => { try { return kavach.interface.parseLog(l); } catch { return null; } })
      .find((e) => e && (e.name === "ClaimSettled" || e.name === "ClaimBlocked"));

    if (outcomeEvent.name === "ClaimSettled") {
      console.log(`OUTCOME     -> SETTLED, payout ${ethers.formatEther(outcomeEvent.args.payoutAmount)} ETH\n`);
    } else {
      console.log(`OUTCOME     -> BLOCKED, reason: ${outcomeEvent.args.reason}\n`);
    }

    const stored = await kavach.getClaim(claimId);
    console.log("on-chain claim state:", {
      state: ["NONE", "PENDING", "SETTLED", "BLOCKED"][stored.state],
      damageScore: stored.damageScore.toString(),
      rainfallDeficit: stored.rainfallDeficit.toString(),
      payoutAmount: ethers.formatEther(stored.payoutAmount) + " ETH",
    });
    console.log("");
  }

  const remaining = await kavach.poolBalance();
  console.log("=== Run complete ===");
  console.log("remaining payout pool:", ethers.formatEther(remaining), "ETH");
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
