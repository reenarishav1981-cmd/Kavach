const hre = require("hardhat");
const { compileKavach } = require("./compile");

async function main() {
  const [deployer, oracle] = await hre.ethers.getSigners();

  console.log("Deploying Kavach…");
  console.log("  owner (insurer): ", deployer.address);
  console.log("  oracle (AI svc): ", oracle.address);

  const { abi, bytecode } = compileKavach();
  const Kavach = new hre.ethers.ContractFactory(abi, bytecode, deployer);
  const kavach = await Kavach.deploy(oracle.address);
  await kavach.waitForDeployment();

  const address = await kavach.getAddress();
  console.log("Kavach deployed at:", address);

  // fund the payout pool so a settled claim can actually pay out in the demo
  const fundTx = await deployer.sendTransaction({
    to: address,
    value: hre.ethers.parseEther("1.0"),
  });
  await fundTx.wait();
  console.log("Funded payout pool with 1.0 ETH (demo testnet value)");

  console.log("\nSave these for scripts/automate.js:");
  console.log("  CONTRACT_ADDRESS =", address);
  console.log("  ORACLE_ADDRESS   =", oracle.address);
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
