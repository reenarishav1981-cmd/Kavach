const fs = require("fs");
const path = require("path");
const solc = require("solc");

function compileKavach() {
  const contractPath = path.join(__dirname, "..", "contracts", "Kavach.sol");
  const source = fs.readFileSync(contractPath, "utf8");

  const input = {
    language: "Solidity",
    sources: { "Kavach.sol": { content: source } },
    settings: {
      optimizer: { enabled: true, runs: 200 },
      outputSelection: { "*": { "*": ["abi", "evm.bytecode.object"] } },
    },
  };

  const output = JSON.parse(solc.compile(JSON.stringify(input)));

  if (output.errors) {
    const fatal = output.errors.filter((e) => e.severity === "error");
    output.errors.forEach((e) => console.log(e.formattedMessage));
    if (fatal.length) throw new Error("Solidity compilation failed");
  }

  const artifact = output.contracts["Kavach.sol"]["Kavach"];
  return {
    abi: artifact.abi,
    bytecode: "0x" + artifact.evm.bytecode.object,
  };
}

module.exports = { compileKavach };
