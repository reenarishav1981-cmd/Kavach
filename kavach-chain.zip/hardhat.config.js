const { task } = require("hardhat/config");
require("@nomicfoundation/hardhat-toolbox");

// This sandbox's network egress doesn't allow binaries.soliditylang.org, which is
// where Hardhat's default compiler manager downloads solc from. We compile
// Kavach.sol ourselves with the pure-JS `solc` npm package instead
// (see scripts/compile.js) and use it directly via ethers.ContractFactory, so
// Hardhat's own compile step is disabled here. On a machine with normal
// internet access you can delete this override and use `npx hardhat compile`
// as usual.
task("compile", async () => {
  console.log("Skipping Hardhat's built-in compiler download — using scripts/compile.js (solc.js) instead.");
});

/** @type import('hardhat/config').HardhatUserConfig */
module.exports = {
  solidity: {
    version: "0.8.19",
    settings: {
      optimizer: { enabled: true, runs: 200 },
    },
  },
  networks: {
    hardhat: {
      chainId: 31337,
    },
  },
};
