const { expect } = require("chai");
const { ethers } = require("hardhat");
const { compileKavach } = require("../scripts/compile");

const { abi, bytecode } = compileKavach();

describe("Kavach", function () {
  async function deployFixture() {
    const [owner, oracle, farmer, other] = await ethers.getSigners();
    const Kavach = new ethers.ContractFactory(abi, bytecode, owner);
    const kavach = await Kavach.deploy(oracle.address);
    await kavach.waitForDeployment();

    await owner.sendTransaction({
      to: await kavach.getAddress(),
      value: ethers.parseEther("1.0"),
    });

    return { kavach, owner, oracle, farmer, other };
  }

  it("lets a farmer file a claim in PENDING state", async function () {
    const { kavach, farmer } = await deployFixture();
    const tx = await kavach.connect(farmer).submitClaim("MH-AGN-0472", "Cotton");
    await tx.wait();

    const claim = await kavach.getClaim(1);
    expect(claim.farmer).to.equal(farmer.address);
    expect(claim.state).to.equal(1); // PENDING
  });

  it("settles and pays out a consistent, high-damage claim", async function () {
    const { kavach, oracle, farmer } = await deployFixture();
    await (await kavach.connect(farmer).submitClaim("MH-AGN-0472", "Cotton")).wait();

    const hash = ethers.keccak256(ethers.toUtf8Bytes("evidence-bundle-1"));
    const balanceBefore = await ethers.provider.getBalance(farmer.address);

    await expect(kavach.connect(oracle).submitAttestation(1, 86, 61, hash))
      .to.emit(kavach, "ClaimSettled")
      .withArgs(1, farmer.address, ethers.parseEther("0.01"));

    const claim = await kavach.getClaim(1);
    expect(claim.state).to.equal(2); // SETTLED

    const balanceAfter = await ethers.provider.getBalance(farmer.address);
    expect(balanceAfter - balanceBefore).to.equal(ethers.parseEther("0.01"));
  });

  it("blocks a claim where damage is high but rainfall deficit doesn't corroborate it", async function () {
    const { kavach, oracle, farmer } = await deployFixture();
    await (await kavach.connect(farmer).submitClaim("MH-AGN-0488", "Cotton")).wait();

    const hash = ethers.keccak256(ethers.toUtf8Bytes("evidence-bundle-2"));

    await expect(kavach.connect(oracle).submitAttestation(1, 81, 4, hash))
      .to.emit(kavach, "ClaimBlocked")
      .withArgs(1, farmer.address, "damage score inconsistent with district rainfall");

    const claim = await kavach.getClaim(1);
    expect(claim.state).to.equal(3); // BLOCKED
    expect(claim.payoutAmount).to.equal(0);
  });

  it("rejects attestations from anyone other than the oracle", async function () {
    const { kavach, farmer, other } = await deployFixture();
    await (await kavach.connect(farmer).submitClaim("MH-AGN-0472", "Cotton")).wait();

    const hash = ethers.keccak256(ethers.toUtf8Bytes("evidence-bundle-3"));
    await expect(
      kavach.connect(other).submitAttestation(1, 90, 70, hash)
    ).to.be.revertedWith("Kavach: caller is not the attestation oracle");
  });

  it("cannot attest the same claim twice", async function () {
    const { kavach, oracle, farmer } = await deployFixture();
    await (await kavach.connect(farmer).submitClaim("MH-AGN-0472", "Cotton")).wait();
    const hash = ethers.keccak256(ethers.toUtf8Bytes("evidence-bundle-4"));
    await (await kavach.connect(oracle).submitAttestation(1, 86, 61, hash)).wait();

    await expect(
      kavach.connect(oracle).submitAttestation(1, 86, 61, hash)
    ).to.be.revertedWith("Kavach: claim is not pending");
  });
});
